/*Практическая работа № 1 */
console.log('__________________');
/*
let x = 10;
let x = Symbol('*');
let x = false;
let x = undefined;
let x = 4925250777218564n;
let x = 'A';
*/ 
let x = undefined;
if (typeof x === 'number'){
    console.log('number');
}   else if (typeof x === 'symbol'){
    console.log('symbol');
}
    else if (typeof x === 'boolean'){
    console.log('boolean');
}
    else if (typeof x === 'undefined'){
    console.log('undefined');
}
    else if (typeof x === 'Biglnt'){
    console.log('Biglnt');
}
    else if (typeof x === 'object'){
    console.log('object');
}
    else if (typeof x === 'string'){
    console.log('string');
}
else if (typeof x === 'null'){
    console.log('null');
}
console.log('__________________');
// Используем цикл while
/*let i = 1;
while (i <= 40) {
    console.log(i);
    i++;
}
console.log('__________________');
// Используем цикл for
for (let i = 1; i <= 40; i++) {
    console.log(i);
}
console.log('__________________');
// Используем цикл do-while
i = 0;
i = 1;
do {
    console.log(i);
    i++;
} while (i <= 40);*/
console.log('__________________');
/*setInterval(() => { console.log(`с постоЯнно повторЯющемсЯ `) }, 1000);*/
console.log('__________________');
/*let arr = ['8','9','10','11','12','13','14','15','16','17','18','19','20']
for (var j=0; j<arr.length; j++){  //j<arr.length// ///j<13//
    if (arr[j] % 2 ==0){
        console.log(arr[j]);
    }
}*/
/*console.log('__________________');
for (let i = 1; i <= 1000; i++) {
    if (i % 3 ==0 || i % 5 ==0){
        console.log(i);
    }
}*/
console.log('__________________');

console.log('__________________');
for (let i = 1; i <= 5; i++) {
    let row = "";
    for (let j = 1; j <= i; j++) {
        row += "*";
    }
    console.log(row);
}
console.log('__________________');

/*Практическая работа № 2 */
console.log('__________________');

/*4*/
console.log(' 4 ');

function solveQuadraticEquation(a, b, c) {
    const discriminant = b * b - 4 * a * c; // Вычисляем дискриминант
  
    if (discriminant > 0) {
      const x1 = (-b + Math.sqrt(discriminant)) / (2 * a); // Вычисляем первый корень
      const x2 = (-b - Math.sqrt(discriminant)) / (2 * a); // Вычисляем второй корень
      return [x1, x2]; // Возвращаем массив с двумя корнями
    } else if (discriminant === 0) {
      const x = -b / (2 * a); // Вычисляем корень, если дискриминант равен нулю
      return [x]; // Возвращаем массив с одним корнем
    } else {
      return []; // Возвращаем пустой массив, если дискриминант меньше нуля
    }
  }
  
  // Пример использования функции для уравнения x^2 - 5x + 6 = 0
  const roots = solveQuadraticEquation(1, -5, 6);
  console.log(roots); // Выводим массив с корнями уравнения
  console.log('__________________');

/*Практическая работа № 3 */
console.log('__________________');
let arr11 = ['h','e','l','l','o']
let arr12 = new Array('h','e','l','l','o');
let arr13 = Array.of('h','e','l','l','o');
console.log('__________________');

console.log(arr11);
console.log(arr11[4]);
arr11[4] = 'p';
console.log(arr11);
console.log(arr11[4]);
console.log('__________________');

let arrlen = document.getElementById(`but`);
arrlen.addEventListener('mouseover', ( )=> {
    document.getElementById(`but`).innerText = (arr11.length);
}) 
console.log('__________________');
let arr14 = ['h','e','l','p','o'];
for (let e = 0; e <arr14.length; e++) {
    console.log(arr14[e]);
}
/*for (let e = 0; e <arr14.length; e++) {
    const element = arr14[e]
    console.log(element);
}*/
console.log('|- - -|');
arr14.forEach(item => {
    console.log(item);
  });
console.log('__________________');
let arr111 = ['1','2','3','4','5'];
let arr112 = ['6','7','8','9','10'];
let arr113 = [...arr111, ...arr112];
console.log(arr113);
for (let t = 0; t <arr113.length; t++) {
    console.log(arr113[t]);
}
console.log('__________________');
arr113.shift();
console.log(arr113);
arr113.pop();
console.log(arr113);
console.log('__________________');

arr113.unshift('11');
console.log(arr113);
console.log('__________________');

/*
let arr2025 = [];
for (let u; u<7; u++){
    alert("введи число мас.");
    prompt(arr2025[u]);
}*/
const inputArray = prompt("Введите массив значений, разделенных запятыми:").split(",");

const squareRootArray = inputArray.map(value => {
  if (!isNaN(value) && value !== "") {
    return Math.sqrt(Number(value));
  } else {
    return "Неверный ввод";
  }
});

console.log(squareRootArray);


console.log('__________________');
setInterval(() => {
    document.getElementById(`Data1`).innerText = Date();
}, 1000)
console.log('__________________');
/*setInterval(() => {
    document.getElementById(`Data2`).innerText = Date();
}, 1000)
console.log('__________________');*/
const months = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
  const today = new Date(); // Получаем текущую дату 
  const day = today.getDate();
  const month = months[today.getMonth()];
  const year = today.getFullYear();
  console.log(`${day}`, `${month}`, `${year}`, 'года'); 
  
  console.log('__________________');


  function multiplyRandomNumbers() {
    const randomNum1 = Math.floor(Math.random() * 51); // Генерируем случайное число от 0 до 50
    const randomNum2 = Math.floor(Math.random() * 51); // Генерируем второе случайное число от 0 до 50
    const product = randomNum1 * randomNum2; // Вычисляем произведение двух случайных чисел
    return product;
  }
  const result = multiplyRandomNumbers();
  console.log(result); // Выводим результат умножения двух случайных чисел
  console.log('__________________');
  
/*Практическая работа № 4 */

/*Практическая работа № 5 */

/*Практическая работа № 6 */