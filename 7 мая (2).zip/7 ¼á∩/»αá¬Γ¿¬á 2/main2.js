/*Практическая работа № 3 */
console.log('ПРАКТИЧЕСКАЯ РАБОТА № 3');
console.log('_______________________');
console.log('№ 1');
//Практическая работа 2
//1
for (let i = 0; i < 5; i++) {
  for (let j = 0; j <= i; j++) {
  console.log("* ");
  }
  console.log();
}
//2 находится в privet.html
//3
const min = (a, b) => Math.min(a, b);
//4
function solveQuadratic(a, b, c) {
  const D = b**2 - 4*a*c;
  if (D < 0) {
  return [];
  }
  const x1 = (-b + Math.sqrt(D)) / (2*a);
  const x2 = (-b - Math.sqrt(D)) / (2*a);
  return [x1, x2];
}
const k = 1;
const y = 2;
const c = 1;
const roots = solveQuadratic(a, b, c);
console.log(roots);
//5 находится в privet.html
console.log('_______________________');


/* Кнопка смены темы*/ 
let styleMode = localStorage.getItem('styleMode');
const styleToggle = document.querySelector('.Tema'); /*.themeToggle*/ 

const enableDarkStyle = () => {
    document.body.classList.add('darkstyle');
    localStorage.setItem('styleMode', 'dark');
}
const disableDarkStyle = () => {
    document.body.classList.remove('darkstyle');
    localStorage.setItem('styleMode', null);
}

styleToggle.addEventListener('click', () => {
    styleMode = localStorage.getItem('styleMode');
    if(styleMode !== 'dark'){
        enableDarkStyle();
    } else {
        disableDarkStyle();
    }
});