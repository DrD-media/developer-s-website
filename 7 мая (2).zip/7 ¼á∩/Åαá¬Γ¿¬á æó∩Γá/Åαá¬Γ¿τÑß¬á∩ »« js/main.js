//Практическая работа 1
//1
let age = 25;
console.log(typeof age); 
if (age >= 18) {
    console.log("Вы совершеннолетний.");
} 
else {
    console.log("Вы несовершеннолетний.");
}
//2
let zodiacSign = prompt("Введите свой знак зодиака:");
switch (zodiacSign) {
    case "Овен":
        alert("Привет, Овен!");
        break;
    case "Телец":
        alert("Привет, Телец!");
        break;
    case "Близнецы":
        alert("Привет, Близнецы!");
        break;
    case "Рак":
        alert("Привет, Рак!");
        break;
    case "Лев":
        alert("Привет, Лев!");
        break;
    case "Дева":
        alert("Привет, Дева!");
        break;
    case "Весы":
        alert("Привет, Весы!");
        break;
    case "Скорпион":
        alert("Привет, Скорпион!");
        break;
    case "Стрелец":
        alert("Привет, Стрелец!");
        break;
    case "Козерог":
        alert("Привет, Козерог!");
        break;
    case "Водолей":
        alert("Привет, Водолей!");
        break;
    case "Рыбы":
        alert("Привет, Рыбы!");
        break;
    default:
        alert("Неизвестный знак зодиака.");
}
//3
//for
for (let i = 1; i <= 40; i++) {
    console.log(i);
}
//while
let a = 1;
while (a <= 40) {
    console.log(a);
    a++;
}
//do...while
let b = 1;
do {
    console.log(b);
    b++;
}   while (b <= 40);
//4 задание в main.html
//5
let num1 = parseInt(prompt("Введите первое число:"));
let num2 = parseInt(prompt("Введите второе число:"));
let num3 = parseInt(prompt("Введите третье число:"));
let sortedNums = [num1, num2, num3].sort((a, b) => a - b);
console.log("Отсортированные числа:", sortedNums);
//6
for (let i = 0; i <= 15; i++) {
    if (i % 2 === 0) {
    console.log(`${i} - четное`);
    } else {
    console.log(`${i} - нечетное`);
    }
}
//7
let number = parseInt(prompt("Введите число больше 5:"));
while (number <= 5 || isNaN(number)) {
    number = parseInt(prompt("Неверный ввод. Введите число больше 5:"));
}
alert("Поздравляем! Вы ввели число больше 5.");
//8
for (let i = 8; i <= 20; i += 2) {
    console.log(i);
}
//9
let sum = 0;
for (let i = 0; i <= 1000; i++) {
    if (i % 3 === 0 || i % 5 === 0) {
        sum += i;
    }
}
console.log("Сумма:", sum);
//10
let numb = parseInt(prompt("Введите трехзначное число:"));
if (numb < 100 || numb > 999) {
    alert("Введено не трехзначное число.");
} 
else {
    let numbString = numb.toString();
    let sum = 0;
    for (let i = 0; i < numbString.length; i++) {
        let digit = parseInt(numbString[i]);
        sum += digit ** 3;
    }
    if (sum === numb) {
        alert("Введенное число является числом Армстронга.");
    } 
    else {
        alert("Введенное число не является числом Армстронга.");
    }
}
//11
for (let i = 0; i < 5; i++) {
    for (let j = 0; j <= i; j++) {
        console.log("* ");
    }
    console.log();
}
//Практическая работа 2
//1
for (let i = 0; i < 5; i++) {
    for (let j = 0; j <= i; j++) {
    console.log("* ");
    }
    console.log();
}
//2 находится в privet.html
//3
const min = (a, b) => Math.min(a, b);
//4
function solveQuadratic(a, b, c) {
    const D = b**2 - 4*a*c;
    if (D < 0) {
    return [];
    }
    const x1 = (-b + Math.sqrt(D)) / (2*a);
    const x2 = (-b - Math.sqrt(D)) / (2*a);
    return [x1, x2];
}
const k = 1;
const y = 2;
const c = 1;
const roots = solveQuadratic(a, b, c);
console.log(roots);
//5 находится в privet.html
//Практическая работа 3
//1
const arr1 = [1, 2, 3, 4, 5];
console.log(arr1);  // 1 способ
const arr2 = new Array(1, 2, 3, 4, 5);
console.log(arr2);  // 2 способ
const arr3 = Array.of(1, 2, 3, 4, 5);
console.log(arr3);  // 3 способ
//2
const arr = [1, 2, 3, 4, 5];
console.log(arr[4]); 
arr[4] = 10;
console.log(arr);
//3
const arrr = [1, 2, 3, 4, 5];
for (let i = 0; i < arrr.length; i++) {
    console.log(arrr[i]);
} //1 способ
const aarr = [1, 2, 3, 4, 5];
const newArr = aarr.map((element) => {
    console.log(element);
    return element;
}); //2 способ
//4
const arr4 = [1, 2, 3];
const arr5 = [4, 5, 6];
const combinacion = [...arr4, ...arr5];
console.log(combinacion); 
//5
const combinedArr = [1,2,3,4,5];
const lastElement = combinedArr.pop();
console.log(lastElement); 
console.log(combinedArr);
//6
combinedArr.unshift(0);
console.log(combinedArr);
//7
const inputArr = prompt("Введите массив значений, разделенных запятыми:").split(",");
const sqrtArr = [];
for (let i = 0; i < inputArr.length; i++) {
    if (!isNaN(inputArr[i])) {
        const sqrt = Math.sqrt(Number(inputArr[i]));
        sqrtArr.push(sqrt);
    } 
    else {
        sqrtArr.push("");
    }
}
console.log(sqrtArr);
//8
const today = new Date().toDateString();
console.log(today);  
//9
const today1 = new Date();
const formattedDate = `${today1.getDate()} ${today1.toLocaleString('en-US', { month: 'long' })} ${today1.getFullYear()}`;
console.log(formattedDate);
//10
function multiplyRandomNumbers() {
    const num1 = Math.floor(Math.random() * 51);
    const num2 = Math.floor(Math.random() * 51);
    return num1 * num2;
}
    const product = multiplyRandomNumbers();
    console.log(`Произведение двух случайных чисел: ${product}`);
//Практическая работа 4
function StudentINPIT(name, age, faculty, group, course) {
    this.name = name;
    this.age = age;
    this.faculty = faculty;
    this.group = group;
    this.course = course;
}
StudentINPIT.prototype.sayName = function() {
    console.log(`Меня зовут ${this.name}`);
};
StudentINPIT.prototype.calculateAge = function() {
    console.log(`Мой возраст: ${this.age}`);
};
const student1 = new StudentINPIT("Иван Иванов", 20, "ИФСТ", 123, 2);
const student2 = new StudentINPIT("Петр Петров", 21, "ИВЧТ", 456, 3);
student1.sayName();
student1.calculateAge();
student2.sayName();
student2.calculateAge();