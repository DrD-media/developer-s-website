const form = document.getElementById('preference-form');
const resultsList = document.querySelector('#results ul');
const movies = [
    { title: "Один дома", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 8.1 },
    { title: "День сурка", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 8.0 },
    { title: "Большой Лебовски", genre: "comedy", era: "modern", mood: "relaxing", basedOn: "original", rating: 8.1 },
    { title: "В джазе только девушки", genre: "comedy", era: "classic", mood: "fun", basedOn: "original", rating: 8.1 },
    { title: "Монти Пайтон и Священный Грааль", genre: "comedy", era: "classic", mood: "fun", basedOn: "original", rating: 8.2 },
    { title: "Поездка в Америку", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 7.3 },
    { title: "Аэроплан!", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 7.7 },
    { title: "Голый пистолет", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 7.3 },
    { title: "Трудности перевода", genre: "comedy", era: "modern", mood: "relaxing", basedOn: "original", rating: 7.7 },
    { title: "Superперцы", genre: "comedy", era: "modern", mood: "fun", basedOn: "original", rating: 7.3 },
    { title: "Матрица", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 8.7 },
    { title: "Терминатор 2: Судный день", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 8.5 },
    { title: "Крепкий орешек", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 8.2 },
    { title: "Рейд", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 7.6 },
    { title: "Джон Уик", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 7.4 },
    { title: "Mad Max: Fury Road", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 8.1 },
    { title: "Убить Билла", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 8.1 },
    { title: "Индиана Джонс: В поисках утраченного ковчега", genre: "action", era: "classic", mood: "fun", basedOn: "original", rating: 8.4 },
    { title: "Хищник", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 7.8 },
    { title: "Скорость", genre: "action", era: "modern", mood: "serious", basedOn: "original", rating: 7.2 },
    { title: "Зеленая миля", genre: "drama", era: "modern", mood: "serious", basedOn: "book", rating: 9.6 },
    { title: "Список Шиндлера", genre: "drama", era: "modern", mood: "serious", basedOn: "book", rating: 8.9 },
    { title: "12 разгневанных мужчин", genre: "drama", era: "classic", mood: "serious", basedOn: "original", rating: 9.0 },
    { title: "Пролетая над гнездом кукушки", genre: "drama", era: "classic", mood: "serious", basedOn: "book", rating: 8.7 },
    { title: "Форрест Гамп", genre: "drama", era: "modern", mood: "relaxing", basedOn: "book", rating: 8.8 },
    { title: "Бойцовский клуб", genre: "drama", era: "modern", mood: "serious", basedOn: "book", rating: 8.8 },
    { title: "Семь", genre: "drama", era: "modern", mood: "serious", basedOn: "original", rating: 8.6 },
    { title: "Молчание ягнят", genre: "drama", era: "modern", mood: "serious", basedOn: "book", rating: 8.6 },
    { title: "Начало", genre: "drama", era: "modern", mood: "serious", basedOn: "original", rating: 8.8 },
    { title: "Темный рыцарь", genre: "drama", era: "modern", mood: "serious", basedOn: "comics", rating: 9.0 },
    { title: "2001 год: Космическая одиссея", genre: "sci-fi", era: "classic", mood: "serious", basedOn: "book", rating: 8.3 },
    { title: "Бегущий по лезвию", genre: "sci-fi", era: "classic", mood: "serious", basedOn: "book", rating: 8.2 },
    { title: "Интерстеллар", genre: "sci-fi", era: "modern", mood: "serious", basedOn: "original", rating: 8.6 },
    { title: "Прибытие", genre: "sci-fi", era: "modern", mood: "serious", basedOn: "short-story", rating: 7.9 },
    { title: "Назад в будущее", genre: "sci-fi", era: "classic", mood: "fun", basedOn: "original", rating: 8.5 },
    { title: "Звездные войны: Эпизод IV - Новая надежда", genre: "sci-fi", era: "classic", mood: "fun", basedOn: "original", rating: 8.6 },
    { title: "Чужой", genre: "sci-fi", era: "classic", mood: "serious", basedOn: "original", rating: 8.4 },
    { title: "E.T. Внеземной", genre: "sci-fi", era: "classic", mood: "fun", basedOn: "original", rating: 7.8 },
    { title: "District 9", genre: "sci-fi", era: "modern", mood: "serious", basedOn: "original", rating: 7.9 },
    { title: "Луна 2112", genre: "sci-fi", era: "modern", mood: "serious", basedOn: "original", rating: 7.9 },
    { title: "Сияние", genre: "horror", era: "classic", mood: "serious", basedOn: "book", rating: 8.4 },
    { title: "Изгоняющий дьявола", genre: "horror", era: "classic", mood: "serious", basedOn: "book", rating: 8.0 },
    { title: "Психо", genre: "horror", era: "classic", mood: "serious", basedOn: "book", rating: 8.5 },
    { title: "Ребенок Розмари", genre: "horror", era: "classic", mood: "serious", basedOn: "book", rating: 8.0 },
    { title: "Техасская резня бензопилой", genre: "horror", era: "classic", mood: "serious", basedOn: "original", rating: 7.4 },
    { title: "Ведьма из Блэр: Курсовая с того света", genre: "horror", era: "modern", mood: "serious", basedOn: "original", rating: 6.4 },
    { title: "Паранормальное явление", genre: "horror", era: "modern", mood: "serious", basedOn: "original", rating: 6.4 },
    { title: "Зловещие мертвецы", genre: "horror", era: "classic", mood: "fun", basedOn: "original", rating: 7.5 },
    { title: "Омен", genre: "horror", era: "classic", mood: "serious", basedOn: "original", rating: 7.5 },
    { title: "Астрал", genre: "horror", era: "modern", mood: "serious", basedOn: "original", rating: 6.8 },
];
function filterMovies(preferences) {
    return movies.filter(movie => {
        return (movie.genre === preferences.genre || preferences.genre === "") &&
               (movie.era === preferences.era || preferences.era === "") &&
               (movie.mood === preferences.mood || preferences.mood === "") &&
               (movie.basedOn === preferences.basedOn || preferences.basedOn === "") &&
               (movie.rating >= preferences.rating);
    });
}
function displayResults(filteredMovies) {
    resultsList.innerHTML = ''; 

    if (filteredMovies.length === 0) {
        const message = document.createElement('li');
        message.textContent = "Нет фильмов, соответствующих вашим предпочтениям.";
        resultsList.appendChild(message);
    } else {
        filteredMovies.forEach(movie => {
            const listItem = document.createElement('li');
            listItem.textContent = movie.title + " (" + movie.rating + ")";
            resultsList.appendChild(listItem);
        });
    }
}
form.addEventListener('submit', function(event) {
    event.preventDefault();

    const preferences = {
        genre: document.getElementById('genre').value,
        era: document.getElementById('era').value,
        mood: document.getElementById('mood').value,
        basedOn: document.getElementById('based-on').value,
        rating: document.getElementById('rating').value
    };

    const filteredMovies = filterMovies(preferences);
    displayResults(filteredMovies);
    localStorage.setItem('preferences', JSON.stringify(preferences));
});
window.addEventListener('load', function() {
    const savedPreferences = JSON.parse(localStorage.getItem('preferences'));
    if (savedPreferences) {
        document.getElementById('genre').value = savedPreferences.genre;
        document.getElementById('era').value = savedPreferences.era;
        document.getElementById('mood').value = savedPreferences.mood;
        document.getElementById('based-on').value = savedPreferences.basedOn;
        document.getElementById('rating').value = savedPreferences.rating;
        const filteredMovies = filterMovies(savedPreferences);
        displayResults(filteredMovies);
    }
});